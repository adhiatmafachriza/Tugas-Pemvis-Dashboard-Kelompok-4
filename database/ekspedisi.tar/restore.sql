--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ekspedisi;
--
-- Name: ekspedisi; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ekspedisi WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Indonesian_Indonesia.1252' LC_CTYPE = 'Indonesian_Indonesia.1252';


ALTER DATABASE ekspedisi OWNER TO postgres;

\connect ekspedisi

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hitung_ongkir(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.hitung_ongkir() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE 
	tarif INT;
	berat INT;
	harga_layanan INT;
	id_provinsi_asal INT;
	id_kota_asal INT;
	id_provinsi_tujuan INT;
	id_kota_tujuan INT;
BEGIN
	tarif := 0;
	id_kota_tujuan := (
		SELECT kota.id_kota
		FROM paket
		INNER JOIN alamat
		ON paket.id_alamat_tujuan = alamat.id_alamat
		INNER JOIN kota
		ON alamat.id_kota = kota.id_kota
		WHERE paket.id_paket = (SELECT MAX(id_paket) FROM paket)
	);
	id_kota_asal := (
		SELECT kota.id_kota
		FROM paket
		INNER JOIN pelanggan
		ON paket.id_pelanggan = pelanggan.id_pelanggan
		INNER JOIN alamat
		ON pelanggan.id_alamat = alamat.id_alamat
		INNER JOIN kota
		ON alamat.id_kota = kota.id_kota
		WHERE paket.id_paket = (SELECT MAX(id_paket) FROM paket)
	);
	id_provinsi_tujuan := (
		SELECT provinsi.id_provinsi
		FROM paket
		INNER JOIN alamat
		ON paket.id_alamat_tujuan = alamat.id_alamat
		INNER JOIN kota
		ON alamat.id_kota = kota.id_kota
		INNER JOIN provinsi
		ON kota.id_provinsi = provinsi.id_provinsi
		WHERE paket.id_paket = (SELECT MAX(id_paket) FROM paket)
	);
	id_provinsi_asal := (
		SELECT provinsi.id_provinsi
		FROM paket
		INNER JOIN pelanggan
		ON paket.id_pelanggan = pelanggan.id_pelanggan
		INNER JOIN alamat
		ON pelanggan.id_alamat = alamat.id_alamat
		INNER JOIN kota
		ON alamat.id_kota = kota.id_kota
		INNER JOIN provinsi
		ON kota.id_provinsi = provinsi.id_provinsi
		WHERE paket.id_paket = (SELECT MAX(id_paket) FROM paket)
	);
	berat := (
		SELECT SUM(barang.berat)
		FROM barang
		INNER JOIN paket
		ON barang.id_paket = paket.id_paket
		WHERE paket.id_paket = (SELECT MAX(id_paket) FROM paket)
	);
	harga_layanan := (
		SELECT layanan.harga
		FROM layanan
		INNER JOIN paket
		ON paket.id_layanan = layanan.id_layanan
		WHERE paket.id_paket = (SELECT MAX(id_paket) FROM paket)
	);
	
	IF id_provinsi_asal != id_provinsi_tujuan THEN
		tarif := tarif + 10000;
	ELSE
		IF id_kota_asal != id_kota_tujuan THEN
			tarif := tarif + 5000;
		ELSE
			tarif := tarif + 2000;
		END IF;
	END IF;
	
	tarif := tarif + harga_layanan + (1000 * berat);
	
	UPDATE paket SET ongkir = tarif WHERE id_paket = (SELECT MAX(id_paket) FROM paket);
	
	RETURN NEW;
END
$$;


ALTER FUNCTION public.hitung_ongkir() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alamat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alamat (
    id_alamat integer NOT NULL,
    id_kota integer NOT NULL,
    alamat character varying(50) NOT NULL,
    nomor_telepon character varying(15),
    kode_pos character varying(10)
);


ALTER TABLE public.alamat OWNER TO postgres;

--
-- Name: alamat_id_alamat_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alamat_id_alamat_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alamat_id_alamat_seq OWNER TO postgres;

--
-- Name: alamat_id_alamat_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alamat_id_alamat_seq OWNED BY public.alamat.id_alamat;


--
-- Name: barang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.barang (
    id_barang integer NOT NULL,
    id_paket integer NOT NULL,
    deskripsi character varying(50) NOT NULL,
    berat integer NOT NULL
);


ALTER TABLE public.barang OWNER TO postgres;

--
-- Name: barang_id_barang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.barang_id_barang_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.barang_id_barang_seq OWNER TO postgres;

--
-- Name: barang_id_barang_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.barang_id_barang_seq OWNED BY public.barang.id_barang;


--
-- Name: kota; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kota (
    id_kota integer NOT NULL,
    id_provinsi integer NOT NULL,
    nama_kota character varying(25) NOT NULL
);


ALTER TABLE public.kota OWNER TO postgres;

--
-- Name: kota_id_kota_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kota_id_kota_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kota_id_kota_seq OWNER TO postgres;

--
-- Name: kota_id_kota_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kota_id_kota_seq OWNED BY public.kota.id_kota;


--
-- Name: layanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.layanan (
    id_layanan integer NOT NULL,
    nama_layanan character varying(10) NOT NULL,
    harga integer NOT NULL
);


ALTER TABLE public.layanan OWNER TO postgres;

--
-- Name: layanan_id_layanan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.layanan_id_layanan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.layanan_id_layanan_seq OWNER TO postgres;

--
-- Name: layanan_id_layanan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.layanan_id_layanan_seq OWNED BY public.layanan.id_layanan;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: paket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paket (
    id_paket integer NOT NULL,
    id_layanan integer NOT NULL,
    id_alamat_tujuan integer NOT NULL,
    nama_penerima character varying(50) NOT NULL,
    tanggal_pengiriman date NOT NULL,
    tanggal_penerimaan date,
    id_pelanggan integer NOT NULL,
    ongkir integer
);


ALTER TABLE public.paket OWNER TO postgres;

--
-- Name: paket_id_paket_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paket_id_paket_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.paket_id_paket_seq OWNER TO postgres;

--
-- Name: paket_id_paket_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.paket_id_paket_seq OWNED BY public.paket.id_paket;


--
-- Name: pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pelanggan (
    id_pelanggan integer NOT NULL,
    id_alamat integer NOT NULL,
    nama_depan character varying(15) NOT NULL,
    nama_belakang character varying(15) NOT NULL
);


ALTER TABLE public.pelanggan OWNER TO postgres;

--
-- Name: pelanggan_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pelanggan_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pelanggan_id_pelanggan_seq OWNER TO postgres;

--
-- Name: pelanggan_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pelanggan_id_pelanggan_seq OWNED BY public.pelanggan.id_pelanggan;


--
-- Name: provinsi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provinsi (
    id_provinsi integer NOT NULL,
    nama_provinsi character varying(25) NOT NULL
);


ALTER TABLE public.provinsi OWNER TO postgres;

--
-- Name: provinsi_id_provinsi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.provinsi_id_provinsi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.provinsi_id_provinsi_seq OWNER TO postgres;

--
-- Name: provinsi_id_provinsi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.provinsi_id_provinsi_seq OWNED BY public.provinsi.id_provinsi;


--
-- Name: alamat id_alamat; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alamat ALTER COLUMN id_alamat SET DEFAULT nextval('public.alamat_id_alamat_seq'::regclass);


--
-- Name: barang id_barang; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.barang ALTER COLUMN id_barang SET DEFAULT nextval('public.barang_id_barang_seq'::regclass);


--
-- Name: kota id_kota; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kota ALTER COLUMN id_kota SET DEFAULT nextval('public.kota_id_kota_seq'::regclass);


--
-- Name: layanan id_layanan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.layanan ALTER COLUMN id_layanan SET DEFAULT nextval('public.layanan_id_layanan_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: paket id_paket; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paket ALTER COLUMN id_paket SET DEFAULT nextval('public.paket_id_paket_seq'::regclass);


--
-- Name: pelanggan id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pelanggan ALTER COLUMN id_pelanggan SET DEFAULT nextval('public.pelanggan_id_pelanggan_seq'::regclass);


--
-- Name: provinsi id_provinsi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provinsi ALTER COLUMN id_provinsi SET DEFAULT nextval('public.provinsi_id_provinsi_seq'::regclass);


--
-- Data for Name: alamat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alamat (id_alamat, id_kota, alamat, nomor_telepon, kode_pos) FROM stdin;
\.
COPY public.alamat (id_alamat, id_kota, alamat, nomor_telepon, kode_pos) FROM '$$PATH$$/2893.dat';

--
-- Data for Name: barang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.barang (id_barang, id_paket, deskripsi, berat) FROM stdin;
\.
COPY public.barang (id_barang, id_paket, deskripsi, berat) FROM '$$PATH$$/2901.dat';

--
-- Data for Name: kota; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kota (id_kota, id_provinsi, nama_kota) FROM stdin;
\.
COPY public.kota (id_kota, id_provinsi, nama_kota) FROM '$$PATH$$/2891.dat';

--
-- Data for Name: layanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.layanan (id_layanan, nama_layanan, harga) FROM stdin;
\.
COPY public.layanan (id_layanan, nama_layanan, harga) FROM '$$PATH$$/2897.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
\.
COPY public.migrations (id, migration, batch) FROM '$$PATH$$/2903.dat';

--
-- Data for Name: paket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paket (id_paket, id_layanan, id_alamat_tujuan, nama_penerima, tanggal_pengiriman, tanggal_penerimaan, id_pelanggan, ongkir) FROM stdin;
\.
COPY public.paket (id_paket, id_layanan, id_alamat_tujuan, nama_penerima, tanggal_pengiriman, tanggal_penerimaan, id_pelanggan, ongkir) FROM '$$PATH$$/2899.dat';

--
-- Data for Name: pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pelanggan (id_pelanggan, id_alamat, nama_depan, nama_belakang) FROM stdin;
\.
COPY public.pelanggan (id_pelanggan, id_alamat, nama_depan, nama_belakang) FROM '$$PATH$$/2895.dat';

--
-- Data for Name: provinsi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.provinsi (id_provinsi, nama_provinsi) FROM stdin;
\.
COPY public.provinsi (id_provinsi, nama_provinsi) FROM '$$PATH$$/2889.dat';

--
-- Name: alamat_id_alamat_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alamat_id_alamat_seq', 33, true);


--
-- Name: barang_id_barang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.barang_id_barang_seq', 30, true);


--
-- Name: kota_id_kota_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kota_id_kota_seq', 100, true);


--
-- Name: layanan_id_layanan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.layanan_id_layanan_seq', 3, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 8, true);


--
-- Name: paket_id_paket_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paket_id_paket_seq', 23, true);


--
-- Name: pelanggan_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pelanggan_id_pelanggan_seq', 15, true);


--
-- Name: provinsi_id_provinsi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.provinsi_id_provinsi_seq', 3, true);


--
-- Name: alamat alamat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alamat
    ADD CONSTRAINT alamat_pkey PRIMARY KEY (id_alamat);


--
-- Name: barang barang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.barang
    ADD CONSTRAINT barang_pkey PRIMARY KEY (id_barang);


--
-- Name: kota kota_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kota
    ADD CONSTRAINT kota_pkey PRIMARY KEY (id_kota);


--
-- Name: layanan layanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.layanan
    ADD CONSTRAINT layanan_pkey PRIMARY KEY (id_layanan);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: paket paket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paket
    ADD CONSTRAINT paket_pkey PRIMARY KEY (id_paket);


--
-- Name: pelanggan pelanggan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pelanggan
    ADD CONSTRAINT pelanggan_pkey PRIMARY KEY (id_pelanggan);


--
-- Name: provinsi provinsi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provinsi
    ADD CONSTRAINT provinsi_pkey PRIMARY KEY (id_provinsi);


--
-- Name: barang tambah_ongkir; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tambah_ongkir AFTER INSERT ON public.barang FOR EACH ROW EXECUTE FUNCTION public.hitung_ongkir();


--
-- Name: alamat alamat_id_kota_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alamat
    ADD CONSTRAINT alamat_id_kota_fkey FOREIGN KEY (id_kota) REFERENCES public.kota(id_kota) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: barang barang_id_paket_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.barang
    ADD CONSTRAINT barang_id_paket_fkey FOREIGN KEY (id_paket) REFERENCES public.paket(id_paket) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kota kota_id_provinsi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kota
    ADD CONSTRAINT kota_id_provinsi_fkey FOREIGN KEY (id_provinsi) REFERENCES public.provinsi(id_provinsi) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: paket paket_id_alamat_tujuan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paket
    ADD CONSTRAINT paket_id_alamat_tujuan_fkey FOREIGN KEY (id_alamat_tujuan) REFERENCES public.alamat(id_alamat) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: paket paket_id_layanan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paket
    ADD CONSTRAINT paket_id_layanan_fkey FOREIGN KEY (id_layanan) REFERENCES public.layanan(id_layanan) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: paket paket_id_pelanggan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paket
    ADD CONSTRAINT paket_id_pelanggan_fkey FOREIGN KEY (id_pelanggan) REFERENCES public.pelanggan(id_pelanggan) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pelanggan pelanggan_id_alamat_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pelanggan
    ADD CONSTRAINT pelanggan_id_alamat_fkey FOREIGN KEY (id_alamat) REFERENCES public.alamat(id_alamat) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

